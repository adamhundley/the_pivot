**To list gateways for an account**

The following ``list-gateways`` command lists all the gateways defined for an account::

    aws storagegateway list-gateways

This command outputs a JSON block that contains a list of gateway Amazon Resource Names (ARNs).
